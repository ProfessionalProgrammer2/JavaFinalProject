package beans;

public class Customer {
	private int id, Age;
	private String SSN, name, Address1, Address2, City, State;

	public Customer(int id, String SSN, String name, int age, String address1, String address2, String city, String state) {
		super();
		this.id = id;
		this.SSN = SSN;
		this.name = name;
		this.Age = age;
		this.Address1 = address1;
		this.Address2 = address2;
		this.City = city;
		this.State = state;
	}

	public Customer() {
	}

	public String getSSN() {
		return SSN;
	}
	public void setSSN(String sSN) {
		SSN = sSN;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getAddress1() {
		return Address1;
	}
	public void setAddress1(String address1) {
		Address1 = address1;
	}
	public String getAddress2() {
		return Address2;
	}
	public void setAddress2(String address2) {
		Address2 = address2;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
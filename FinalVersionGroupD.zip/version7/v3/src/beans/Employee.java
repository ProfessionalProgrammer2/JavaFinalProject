package beans;

public class Employee {
	int empId;
	String password;
	public Employee(int eId, String pwd){
		this.empId = eId;
		this.password = pwd;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
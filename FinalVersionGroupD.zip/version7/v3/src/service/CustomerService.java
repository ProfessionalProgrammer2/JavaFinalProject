package service;

import java.util.List;

import beans.Customer;
import dao.CustomerDao;

public class CustomerService {
	public static List<Customer> retrieveCustomers(int customerId){
		CustomerDao dao = new CustomerDao();
		
		return dao.retrieveCustomers(customerId);
	}
}

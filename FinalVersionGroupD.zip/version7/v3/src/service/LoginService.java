package service;

import beans.Employee;
import dao.EmployeeDao;
import dao.LoginDao;

public class LoginService {
	public static boolean authenticateEmployee(String empId, String password){
		LoginDao dao = new LoginDao();
		return dao.authenticateUser(empId, password);
	}
}

package service;

import java.util.List;

import beans.Employee;
import dao.EmployeeDao;

public class EmployeeService {
	public static List<Employee> retrieveEmployees(int empId){
		EmployeeDao dao = new EmployeeDao();
		
		return dao.retrieveEmployees(empId);
	}
}

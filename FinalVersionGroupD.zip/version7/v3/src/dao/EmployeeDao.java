package dao;

import java.util.List;

import beans.Employee;

public class EmployeeDao {

	public List<Employee> retrieveEmployees(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
}

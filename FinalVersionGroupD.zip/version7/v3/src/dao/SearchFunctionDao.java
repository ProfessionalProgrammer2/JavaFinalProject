package dao;

public class SearchFunctionDao {

}

package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.Customer;

public class CustomerDao {

	public static final String JDBC_URL = "jdbc:oracle:thin:@02HW045162:1521:xe";

	public static final String USERNAME = "usilp";

	public static final String PASSWORD = "usilp";

	public static Connection con = null;

	public ResultSet rs = null;
	
	public static void addCustomer(Customer c) {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			Connection con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

			String query="INSERT INTO CUSTOMER_D(CUST_ID, CUST_SSN, CUST_NAME, CUST_AGE, "
					+ "CUST_ADDRESS_L1, CUST_ADDRESS_L2, CUST_CITY, CUST_STATE) VALUES (?,?,?,?,?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(query);

			ps.setInt(1, c.getId());

			ps.setString(2, c.getSSN());

			ps.setString(3, c.getName());

			ps.setInt(4, c.getAge());

			ps.setString(5, c.getAddress1());

			ps.setString(6, c.getAddress2());

			ps.setString(7, c.getCity());

			ps.setString(8, c.getState());
			
			ps.executeUpdate();
			System.out.println("succeeded at executing");
			
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Exception occured: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception occured: " + e.getMessage());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<Customer> retrieveCustomers(int custId){
		List<Customer> customers = new ArrayList<Customer>();
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
			
			String customerQuery="select c1.CUSTID, c1.SSN, c1.NAME, c1.AGE, c1.ADDRESSL1, c1.ADDRESSL2, c1.CITY, c1.STATE";
			
			PreparedStatement ps=con.prepareStatement(customerQuery);
			
			ps.setInt(1, custId);
			
			rs=ps.executeQuery();
			
			while(rs.next()){
				// id, ssn, name, age, addressL1, addressL2, city, state
				// cust_*
				
				Customer cust = new Customer();
				cust.setId(rs.getInt("Cust_ID"));
				cust.setSSN(rs.getString("Cust_SSN"));
				cust.setName(rs.getString("Cust_NAME"));				
				cust.setAge(rs.getInt("Cust_AGE"));
				cust.setAddress1(rs.getString("Cust_ADDRESSL1"));
				cust.setAddress2(rs.getString("Cust_ADDRESSL2"));
				cust.setCity(rs.getString("Cust_CITY"));
				cust.setState(rs.getString("Cust_STATE"));
			}
			
		}catch(ClassNotFoundException | SQLException e){
			System.out.println(e);
		}catch(Exception ex){
			System.out.println(ex);
		}finally{
			try{
				if(rs!=null){
					rs.close();
				}
				if(con!=null){
					con.close();
				}
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return customers;
	}
	
	public static boolean authenticateCustomer(int Id, String SSN) {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

			String query="SELECT * FROM CUSTOMER_D WHERE CUST_ID=? OR CUST_SSN=?";
			PreparedStatement ps = con.prepareStatement(query);

			ps.setInt(1, Id);
			ps.setString(2, SSN);

			int count = ps.executeUpdate();

			if (count > 0) {
				return true;
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Exception occured: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception occured: " + e.getMessage());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
}

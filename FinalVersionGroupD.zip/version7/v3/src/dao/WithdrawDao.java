package dao;

import java.sql.*;

public class WithdrawDao {

	public static final String JDBC_URL = "jdbc:oracle:thin:@02HW045162:1521:xe";

	public static final String USERNAME = "usilp";

	public static final String PASSWORD = "usilp";

	public static void withdrawMoney(int ID, double withdrawAmount) {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
			String query = "UPDATE ACCOUNT_D SET BALANCE = BALANCE - ? WHERE CUST_ID=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setDouble(1, withdrawAmount);
			ps.setInt(2, ID);
			ResultSet rs = ps.executeQuery();
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static boolean authenticateCustomer(int ID) {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			con = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);

			String query = "SELECT * FROM CUSTOMER_D WHERE CUST_ID=?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, ID);
			int count = ps.executeUpdate();

			if (count > 0) {
				return true;
			}
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("Exception occured: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception occured: " + e.getMessage());
		} finally {
			try {
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
}
package controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.WithdrawDao;

public class WithdrawController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int ID = Integer.parseInt(request.getParameter("Customer_Id"));
		Double withdrawAmount = Double.parseDouble(request.getParameter("withdrawAmount"));
		if(WithdrawDao.authenticateCustomer(ID)){
			WithdrawDao.withdrawMoney(ID, withdrawAmount);
			response.sendRedirect("withdrawSuccess.jsp");
		}else{
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<h3><font color='red'>Customer Id is invalid</font></h3>");
			RequestDispatcher rd = request.getRequestDispatcher("withdraw.jsp");
			rd.include(request, response);
		}
	}
}
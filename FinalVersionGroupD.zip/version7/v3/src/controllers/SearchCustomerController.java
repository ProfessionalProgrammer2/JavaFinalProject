package controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SearchCustomerController extends HttpServlet{
	public SearchCustomerController(){
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		String newUser = (String)session.getAttribute("user");
		if ((newUser==null) || ((request.getParameter("SSNId") == null) && (request.getParameter("customerNum") == null))){
			
		}else{ 
        	String SSN = request.getParameter("SSNId");
        	String CUST_ID = (request.getParameter("customerNum"));
        	
        	session.setAttribute("SSN_search", SSN);
        	session.setAttribute("CUSTID_search", CUST_ID);
        	response.sendRedirect("searchSuccess.jsp");
		}
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
	}
}

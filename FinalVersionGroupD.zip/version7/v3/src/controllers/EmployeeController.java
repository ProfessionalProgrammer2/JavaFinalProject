package controllers;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Employee;
import service.EmployeeService;

public class EmployeeController {
	public EmployeeController(){
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		int employeeId = Integer.parseInt(request.getParameter("employeeId"));
		
		List<Employee> employees = EmployeeService.retrieveEmployees(employeeId);
		
		if(employees !=null){
			request.setAttribute("employees", employees);
			RequestDispatcher rd = request.getRequestDispatcher("loginSuccess.jsp");
			rd.forward(request, response);
		}else{
			response.sendRedirect("loginFail.jsp");
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException{
	}
}

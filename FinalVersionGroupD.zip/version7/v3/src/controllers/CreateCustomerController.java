package controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.Customer;
import dao.CustomerDao;

public class CreateCustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int ID = Integer.parseInt(request.getParameter("Customer_id"));
		String SSN = (String)(request.getParameter("Customer_SSN"));
		String name = request.getParameter("Customer_name");
		int age = Integer.parseInt(request.getParameter("age"));
		String address1 = request.getParameter("address1");
		String address2 = request.getParameter("address2");
		String state = request.getParameter("state");
		String city = request.getParameter("city");
		if (!CustomerDao.authenticateCustomer(ID, SSN)) {
			Customer c = new Customer(ID, SSN, name, age, address1, address2, city, state);
			CustomerDao.addCustomer(c);
			System.out.println(ID);
			response.sendRedirect("createCustomerSuccess.jsp");
		} else {

			response.setContentType("text/html");
			RequestDispatcher rd = request.getRequestDispatcher("create.jsp");
			rd.include(request, response);
		}
	}
}